
import ETradingPlatform from './ETradingPlatform';

export default function App() {
  return <ETradingPlatform />;
}
